# Operating Model

## Weekly cadence
- One shipped outcome per week
- One public build log per week
- One public-safe impact record per week

## How decisions are made
- Prefer small experiments
- Prefer written artifacts
- Prefer measurable success criteria
