# Docs

- `VISION.md` - the why
- `PRINCIPLES.md` - the ethics + operating principles
- `OPERATING_MODEL.md` - how we execute
- `ARCHITECTURE.md` - high level structure
- `FAQ.md` - quick answers
