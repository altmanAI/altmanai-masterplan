# DailyPilot - North Star

DailyPilot is a human-first daily prioritization companion.

## Promise
Reduce stress. Increase clarity. Make today doable.

## v0.1 focus
- Capture tasks
- Ask 3-5 questions to understand the user's state
- Produce a simple, humane plan for the day
- Explain why each item is recommended

## Success metric (v0.1)
User reports: "I feel less overwhelmed and I know what to do next."
