# Civic Knowledge Engine - North Star

Convert civic data into transparent, traceable public knowledge.

## v0.1 focus
- Ingest one dataset
- Preserve original source reference
- Provide explainable transformations
- Output claims with citations to the source

## Guardrails
- No misrepresentation of sources
- Prefer official datasets
- Clear uncertainty
