# Projects

Hub folder for product tracks. Product repos may later split out, but we track intent and scope here first.

- `dailypilot/`
- `impact-explorer/`
- `civic-knowledge-engine/`
