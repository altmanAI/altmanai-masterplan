# Build Logs

One log per week. Keep it real.

Suggested format:
- What shipped
- What broke
- What we learned
- Next week plan
