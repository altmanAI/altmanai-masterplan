# Governance

## Purpose
This repo is the **public execution hub** for the AltmanAI x Humanity MasterPlan.

## Maintainers
- AltmanAI by Altman Family Group, LLC

## Decision-making
- Default: maintainers decide
- For major changes: open an Issue first; document tradeoffs and acceptance criteria

## Safety and ethics
Human dignity and well-being are non-negotiable. If a proposal increases risk to people, we slow down, redesign, or reject it.

© Altman Family Group, LLC. All rights reserved. ™
