## Summary
What does this change do?

## Checklist
- [ ] Public-safe (no secrets / no private personal data)
- [ ] Documentation updated where needed
- [ ] `python3 tools/validate_repo.py` passes
- [ ] `python3 tools/run_self_test.py` passes

## Notes
Anything reviewers should know?
