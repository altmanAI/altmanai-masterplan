---
name: Feature request
about: Propose a feature with acceptance criteria
title: "[FEAT] "
labels: enhancement
assignees: ''
---

## Problem
What problem are we solving?

## Proposed solution
Describe the change.

## Acceptance criteria
- [ ]
- [ ]

## Risks / ethics / privacy
Any potential human-impact risks? How do we mitigate?
