---
name: Bug report
about: Report a reproducible bug
title: "[BUG] "
labels: bug
assignees: ''
---

## What happened
Describe the issue.

## Steps to reproduce
1.
2.
3.

## Expected behavior
What should have happened.

## Environment
- OS:
- Python version:
