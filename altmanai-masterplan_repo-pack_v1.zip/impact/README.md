# Impact Registry

This folder stores public-safe impact entries.

- `records/` contains one JSON file per impact entry.
- `receipts/` contains receipts that bind artifacts to records.

Validator tools live in `tools/`.
