# Public Safety Boundary

This repository is public. Do not commit:
- Secrets (API keys, tokens, private workflows, etc.)
- Personal data of private individuals
- Private contracts, bank info, IDs, or sensitive operational details

If in doubt: don't publish it here.
